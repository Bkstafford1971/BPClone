# BLOODSPIRE — Playtester Setup Guide

Welcome to the Bloodspire playtest! This guide will walk you through everything you need to get up and running.

---

## Requirements

- **Windows PC**
- **Python 3** — Download from [python.org](https://www.python.org/downloads/)
  - During installation, check the box that says **"Add Python to PATH"**
- **Tailscale** — Free VPN client required to connect to the league server

---

## Step 1 — Install the Game Files

1. Download or clone this repository
2. Copy **all files** into the following directory, creating it if it doesn't exist:

```
C:\Bloodspire
```

Your folder should look like this when done:

```
C:\Bloodspire\
    START_GAME.bat
    gui_server.py
    Bloodspire_client.html
    Bloodspire.png
    combat.py
    narrative.py
    warrior.py
    strategy.py
    weapons.py
    armor.py
    races.py
    team.py
    save.py
    scout_report.py
    matchmaking.py
    accounts.py
    newsletter.py
    ai.py
    ... (all other files)
```

---

## Step 2 — Install and Set Up Tailscale

Bloodspire uses [Tailscale](https://tailscale.com/) to connect your client to the league server securely over a private VPN. This is free and takes about 5 minutes.

1. Click this link to join my Tailscale network: [Join My Tailnet](https://your-invite-link-here)
2. Sign up or log in with your preferred method (Google, Microsoft, GitHub, etc.).
3. Download and install the Tailscale client for your device.
4. Once connected, you should automatically see my server (look for its hostname or use MagicDNS if enabled).

The link will guide you through the entire process.

---

## Step 3 — Launch the Game

1. Open `C:\Bloodspire` in Windows Explorer
2. Double-click **START_GAME.bat**
3. A command window will open — **leave it running in the background**
4. Your browser should open automatically to the Bloodspire client
   - If it doesn't, open your browser and go to: `http://localhost:8765`

---

## Step 4 — Connect to the League Server

1. In the Bloodspire client, click the **Action** menu at the top
2. Select **Account Settings...**
3. In the **League Server URL** field, enter:

```
http://100.114.138.61:8766
```

4. Click **Connect** (or save the settings)
5. You should see a connection confirmation — you're now linked to the live league!

> **Note:** You must have Tailscale running and your share accepted before this URL will work.

---

## Step 5 — Create Your Account and Team

1. On the login screen, choose **New Player** and fill in your details
2. After logging in, click **New Team** to create your roster
3. Build your team — assign warrior names, races, attributes, and equipment
4. When ready, go to **Action → Upload** to submit your team to the league
5. After the league admin runs a turn, go to **Action → Download** to get your results

---

## How a Turn Works

- The league admin runs turns on a set schedule
- Before each turn deadline, **Upload** your team with any strategy changes
- After the turn runs, **Download** your results to see fight narratives, standings, and the newsletter
- Read the **Arena Newsletter** under the Newsletters tab for the full turn recap

---

## Troubleshooting

**The game won't start / START_GAME.bat closes immediately**
- Make sure Python 3 is installed and was added to PATH during installation
- Open a Command Prompt, navigate to `C:\Bloodspire`, and run `python gui_server.py` manually to see any error messages

**Can't connect to the league server**
- Make sure Tailscale is installed, running, and your share invite has been accepted
- Double-check the server URL is exactly `http://100.114.138.61:8766`
- Try pinging the server from Tailscale's status screen

**Browser doesn't open automatically**
- Manually navigate to `http://localhost:8765` in any browser

---

## Questions or Issues?

Email the league admin at **bkstafford1971@gmail.com**

Good luck in the arena!
